function main() {
    var canvas = document.getElementById("glcanvas");
    if(!canvas){
        console.log("canvas not exist");
        return;
    }

    var ctx = canvas.getContext("2d");

    ctx.fillStyle = 'rgba(0,0,255,1.0)';
    ctx.fillRect(120,10,150,150);
}